#ifndef __MODE_H_
#define __MODE_H_

#define PI 3.1415926
#define Height 70
#define Servo_Mid 86
void Mode_1(int distance, int alpha);
void Mode_2(int distance_mv);
void Mode_3(void);

int Angle1_Calcu_Molde2(int Angle_last);
int Angle2_Calcu(int distance);
void Auto_Lanuch(void);

#endif

