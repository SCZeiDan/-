#ifndef __JQ8400_H
#define	__JQ8400_H


#include "stm32f10x.h"

/*����3����*/
      

// BUSY
//#define JQ8400_BUSY    	    GPIOA			              /* GPIO�˿� */
//#define JQ8400_BUSY_CLK 	  RCC_APB1Periph_GPIOA		/* GPIO�˿�ʱ�� */
//#define JQ8400_BUSY_PIN		  GPIO_Pin_5			        /* ���ӵ�SCLʱ���ߵ�GPIO */

          
void Usart3_Send8bit( USART_TypeDef * pUSARTx, uint8_t eight);
void USART3_Config(void);
void Usart3_Send32bit( USART_TypeDef * pUSARTx, uint32_t ch);
void asong_stop(void);
void playsong(int i);

#endif /* __JQ8400_H */


