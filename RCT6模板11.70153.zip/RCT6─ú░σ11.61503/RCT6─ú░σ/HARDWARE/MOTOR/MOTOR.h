#ifndef __MOTOR_H_
#define __MOTOR_H_

#include "stm32f10x.h"

#define MED_POSITION_1          90
#define MED_POSITION_2          86

#define TIM_ARR  199

#define TIM_PSC  719

#define Motor_AIN0 PBout(10)
#define Motor_AIN1 PBout(11)
#define Motor_BIN0 PBout(14)
#define Motor_BIN1 PBout(15)


void DC_Motor_Init(void);
void DC_Motor_Forward(int stop_flag);
int DC_Motor_Stop();


void DC_Motor_TurnLeft(int stop_flag, int IN1, int IN2, int IN3);
void DC_Motor_TurnLeft_Fast(int stop_flag);

void DC_Motor_TurnLeft(int stop_flag, int IN1, int IN2, int IN3);
void DC_Motor_TurnRight_Fast(int stop_flag);

void Prepare(int *stop_flag);
void Tracing(int *stop_flag, int *crossing, int *room_end, int IN1, int IN2, int IN3);
void Turn(int *stop_flag, int *crossing, int *crossing_num, int dir,int *room_end);
void Turn180(int *stop_flag, int *room_end, int *cargo);
void TurnBack(int *stop_flag, int *crossing, int *crossing_num, int *room_end);




void DC_MotorA(int rev);
void DC_MotorB(int rev);

#endif


