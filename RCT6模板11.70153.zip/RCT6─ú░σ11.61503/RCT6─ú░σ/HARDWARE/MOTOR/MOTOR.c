#include "MOTOR.h"
#include "usart.h"
#include "oled.h"
#include "pwm.h"
#include "stm32f10x.h"
#include "delay.h"
#include "ldr.h"
#include "LED.h"
#include "HX711.h"

#define Kp_R  0.8   // ��ת�����ϵ��
#define Kp_L  0.8  // ��ת�����ϵ��

#define ADC1_PAR	180
#define ADC2_PAR 	180

/***
���1��ˮƽ���򣨵ײ���PA8
���2����ֱ�����Ϸ���PA11
***/


extern int Motor_A, Motor_B;
extern int Motor_Init_Val;


extern int num_detect;
extern int num_direction;

extern int L, M, R;
extern int ADC_1, ADC_2, ADC_3;
extern int ADC_1_val, ADC_2_val, ADC_3_val;
extern int Init_Gray;
extern int Init_Gray_M;



void DC_Motor_Init(){

		GPIO_InitTypeDef GPIO_InitStructure;
		  
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); 	//ʹ��PORTAʱ��	
		
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;           //GPIOFA
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;        //�����������
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	//�ٶ�50MHz
		GPIO_Init(GPIOB,&GPIO_InitStructure);              //��ʼ��PA4
		GPIO_SetBits(GPIOB, GPIO_Pin_10);
	
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;           //GPIOFA
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;        //�����������
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	//�ٶ�50MHz
		GPIO_Init(GPIOB,&GPIO_InitStructure);              //��ʼ��PA5
		GPIO_SetBits(GPIOB, GPIO_Pin_11);
		
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;           //GPIOFA
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;        //�����������
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	//�ٶ�50MHz
		GPIO_Init(GPIOB,&GPIO_InitStructure);              //��ʼ��PA3
		GPIO_SetBits(GPIOB, GPIO_Pin_14);
	
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;           //GPIOFA
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;        //�����������
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	//�ٶ�50MHz
		GPIO_Init(GPIOB,&GPIO_InitStructure);              //��ʼ��PA5
		GPIO_SetBits(GPIOB, GPIO_Pin_15);
	
		TIM3_PWM_Init(TIM_ARR, TIM_PSC);
		TIM_SetCompare3(TIM3, 0);        // ���� PWM1 PB0
		TIM_SetCompare4(TIM3, 0);        // ���� PWM2 PB1
	
}


void DC_Motor_Forward(int stop_flag){

    if(stop_flag == 0){
        //printf("MoveForward!!\r\n");
        Motor_AIN0 = 1;
        Motor_AIN1 = 0;
        Motor_BIN0 = 1;
        Motor_BIN1 = 0;

        TIM_SetCompare3(TIM3, 50);
        TIM_SetCompare4(TIM3, 50);
    }

    
}

int DC_Motor_Stop(){
    //printf("Stop!!\r\n");
    Motor_AIN0 = 1;
    Motor_AIN1 = 0;
    Motor_BIN0 = 1;
    Motor_BIN1 = 0;

    TIM_SetCompare3(TIM3, 10);
    TIM_SetCompare4(TIM3, 10);
    return 1;
}


void DC_Motor_TurnLeft(int stop_flag, int IN1, int IN2, int IN3){
        
    int PWM;
    if(stop_flag == 0){
        //printf("TurnLeft!!\r\n");
        Motor_AIN0 = 1;
        Motor_AIN1 = 0;
        Motor_BIN0 = 0;
        Motor_BIN1 = 1;
        
        PWM = Kp_L * (Left_Diff - (ADC_1_val-ADC_2_val));
        if(PWM > 120)
            PWM = 120;
        TIM_SetCompare3(TIM3, PWM);
        TIM_SetCompare4(TIM3, PWM);
    }
    
    
}

void DC_Motor_TurnLeft_Fast(int stop_flag){

     if(stop_flag == 0){
        Motor_AIN0 = 1;
        Motor_AIN1 = 0;
        Motor_BIN0 = 0;
        Motor_BIN1 = 1;
        
        TIM_SetCompare3(TIM3, 50);
        TIM_SetCompare4(TIM3, 50);
     }
    
    
}

void DC_Motor_TurnRight(int stop_flag, int IN1, int IN2, int IN3){

    int PWM;
    if(stop_flag == 0){
        //printf("TurnRight!!\r\n");
        
        Motor_AIN0 = 0;
        Motor_AIN1 = 1;
        Motor_BIN0 = 1;
        Motor_BIN1 = 0;
        
        PWM = Kp_R * (Right_Diff - (ADC_3_val - ADC_2_val) );
        if(PWM > 100)
            PWM = 100;
        
        TIM_SetCompare3(TIM3, PWM);
        TIM_SetCompare4(TIM3, PWM);
    
    }
    
}



void DC_Motor_TurnRight_Fast(int stop_flag){

    if(stop_flag == 0){
        
        Motor_AIN0 = 0;
        Motor_AIN1 = 1;
        Motor_BIN0 = 1;
        Motor_BIN1 = 0;
        
        TIM_SetCompare3(TIM3, 50);
        TIM_SetCompare4(TIM3, 50);
    }

}

void Prepare(int *stop_flag){
    
    while(num_detect == 0){

    }
    *stop_flag = 0;

}

extern int Weight_Shiwu;

void Tracing(int *stop_flag, int *crossing, int *room_end, int IN1, int IN2, int IN3){
    
    if(*crossing == 0){
    
        if(L == 0 && M == 0 && R == 1){
            DC_Motor_TurnRight(*stop_flag, IN1, IN2, IN3);
        }
        else if(L == 1 && M == 0 && R == 0){
            DC_Motor_TurnLeft(*stop_flag, IN1, IN2, IN3);
        }
        else if(L == 1 && M == 1 && R == 0){
            DC_Motor_TurnLeft(*stop_flag, IN1, IN2, IN3);
        }
        else if(L == 0 && M == 1 && R == 1){
            DC_Motor_TurnRight(*stop_flag, IN1, IN2, IN3);
        }
        else if(L == 0 && M == 1 && R == 0){
						if(Init_Gray - ADC_1_val > ADC1_PAR){
								*stop_flag = DC_Motor_Stop();
								*crossing = 1;
								printf("Crossing\r\n");
							  printf("\n\nADC1_val = %d\t\tADC2_val = %d\t\tADC3_val = %d\t\tL = %d\t\tM = %d\t\tR = %d\t\tInitGray = %d\t\tInitGrayM = %d\r\n", ADC_1_val, ADC_2_val, ADC_3_val, L, M, R,Init_Gray, Init_Gray_M);

								delay_ms(200);
						}	
						
						else if(ADC_2_val - Init_Gray_M > ADC2_PAR){
								*stop_flag = DC_Motor_Stop();
								*room_end = 1;
								printf("Room End\r\n");
								LED_red = 1;
								delay_ms(1500);
								delay_ms(1500);
//								while(Weight_Shiwu > 180)
//								{
//									Get_Weight();
//								}
						}
						
						else
								DC_Motor_Forward(*stop_flag);
        }
				
        else if(L == 0 && M == 0 && R == 0){
            DC_Motor_Forward(*stop_flag);
        }
				
        else if(L == 1 && M == 0 && R == 1){
            if(Init_Gray - ADC_1_val > ADC1_PAR){
								*stop_flag = DC_Motor_Stop();
								*crossing = 1;
								printf("Crossing\r\n");
   							printf("\n\nADC1_val = %d\t\tADC2_val = %d\t\tADC3_val = %d\t\tL = %d\t\tM = %d\t\tR = %d\t\tInitGray = %d\t\tInitGrayM = %d\r\n", ADC_1_val, ADC_2_val, ADC_3_val, L, M, R,Init_Gray, Init_Gray_M);
								delay_ms(500);
						}	
        }
//        else if(L == 1 && M == 1 && R == 1){
//            *stop_flag = DC_Motor_Stop();
//            *crossing = 1;
//        }   
    }
           
}
extern int Arr_turn[4];

void Turn(int *stop_flag, int *crossing, int *crossing_num, int dir, int *room_end){
    
    if((*crossing) == 1 && (*room_end) == 0){

        if(dir == 0){
            *stop_flag = 0;
            DC_Motor_TurnLeft_Fast(*stop_flag);
        }
        else if(dir == 1){
            *stop_flag = 0;
            DC_Motor_TurnRight_Fast(*stop_flag);
        }
        else {
            *stop_flag = 0;
            DC_Motor_Forward(*stop_flag);
        }
        delay_ms(400);		//180�ȵ�ͷ 500ms   pwm=100
				DC_Motor_Forward(*stop_flag);
				delay_ms(300);
        *crossing = 0;
				
				Arr_turn[*crossing_num] = dir;
				printf("Arr_turn[%d] = %d\r\n",*crossing_num, Arr_turn[*crossing_num]);
				(*crossing_num) ++;
    }

}

void TurnBack(int *stop_flag, int *crossing, int *crossing_num, int *room_end)
{
	
	if((*crossing) == 1 && (*room_end) == 1){
			
				(*crossing_num) --;
				printf("Arr_turn[%d] = %d\r\n",*crossing_num, Arr_turn[*crossing_num]);
			
        if(Arr_turn[*crossing_num] == 1){
            *stop_flag = 0;
            DC_Motor_TurnLeft_Fast(*stop_flag);
        }
        else if(Arr_turn[*crossing_num] == 0){
            *stop_flag = 0;
            DC_Motor_TurnRight_Fast(*stop_flag);
        }
        else {
            *stop_flag = 0;
            DC_Motor_Forward(*stop_flag);
        }
        delay_ms(400);		//180�ȵ�ͷ 500ms   pwm=100
				DC_Motor_Forward(*stop_flag);
				delay_ms(300);
        *crossing = 0;
        
    }
}


// ������
void Turn180(int *stop_flag, int *room_end, int *cargo){
	
		if((*cargo) == 0 && (*room_end) == 1){
			*stop_flag = 0;
//			DC_Motor_TurnLeft_Fast(*stop_flag);
//			delay_ms(400);		//180�ȵ�ͷ 500ms   pwm=100
//			DC_Motor_Forward(*stop_flag);
//			delay_ms(300);
			
			DC_Motor_TurnLeft_Fast(*stop_flag);
			delay_ms(1200);		//180�ȵ�ͷ 500ms   pwm=100
//			DC_Motor_Forward(*stop_flag);
//			delay_ms(300);
			
			*cargo = 1;
			
		}

}


void DC_MotorA(int rev)
{
		if(rev==1)
		{
		  PAout(4) = 1; // ˳ʱ��
			PAout(5) = 0;
		}
		else
		{
			PAout(4) = 0; // ��ʱ��
			PAout(5) = 1;
		}
		
        
}

void DC_MotorB(int rev)
{
		if(rev==1)
		{
		  PAout(11) = 1; // ˳ʱ��
		  PAout(12) = 0;
		}
		else
		{
			PAout(11) = 0; // ��ʱ��
			PAout(12) = 1;
		}
		
}





