#ifndef __INFRARED_H_
#define __INFRARED_H_

#include "stm32f10x.h"
void Infrared_GPIO_Configuration();
void Infrared_GPIO_Read(uint8_t *state_1, uint8_t *state_2);

#endif
