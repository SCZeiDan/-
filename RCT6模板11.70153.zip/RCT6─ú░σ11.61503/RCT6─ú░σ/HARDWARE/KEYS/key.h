#ifndef __KEY_H
#define	__KEY_H

#include "stm32f10x.h"

#define R1_Pin GPIO_Pin_12
#define R2_Pin GPIO_Pin_13
#define R3_Pin GPIO_Pin_14
#define R4_Pin GPIO_Pin_15

#define C1_Pin GPIO_Pin_3
#define C2_Pin GPIO_Pin_2
#define C3_Pin GPIO_Pin_1
#define C4_Pin GPIO_Pin_0

#define R1 PCout(0)	// PC0
#define R2 PCout(1)	// PC1
#define R3 PCout(2)	// PC2
#define R4 PCout(3)	// PC3

#define C1 PAin(2)	// PA2
#define C2 PAin(1)	// PA1
#define C3 PAin(0)	// PA0
#define C4 PAin(4)	// PA3

#define C1_PRES 1 // C1 ����
#define C2_PRES 2 // C2 ����
#define C3_PRES 3 // C3 ����
#define C4_PRES 4 // C4 ����

#define Mode_Change 10
#define Setting_Finish 11
#define Unknow 99

void Rx_PRES(int Rx);

#define KEY_ON 0
#define KEY_OFF 1

void Key_Init(void);
u8 KeyScan(void);
u8 KEY_Cx_Scan(u8);
void key_value_process(void);
 


#endif
