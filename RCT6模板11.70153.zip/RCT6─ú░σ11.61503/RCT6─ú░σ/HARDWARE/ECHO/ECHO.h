#ifndef __ECHO_H_

#define __ECHO_H_
#include "stm32f10x.h"



#define HCSR04_PORT     GPIOA
#define HCSR04_CLK      RCC_APB2Periph_GPIOA
#define HCSR04_TRIG     GPIO_Pin_6
#define HCSR04_ECHO     GPIO_Pin_7
#define HCSR04_TIM      TIM2
 
#define TRIG_Send  PAout(6) 
#define ECHO_Reci  PAin(7)

extern u16 msHcCount;

void Echo_Init(void);
void TIM_Config_Hc(void);
u32 GetEchoTimer(void);
float Hcsr04GetLength(void);
void TIM2_IRQHandler(void);

#endif

