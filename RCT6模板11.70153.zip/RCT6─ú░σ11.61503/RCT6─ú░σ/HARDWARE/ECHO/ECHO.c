#include "ECHO.h"
#include "stm32f10x.h"
#include "delay.h"



void Echo_Init(void){
    
    GPIO_InitTypeDef GPIO_InitStructure;
    
    RCC_APB2PeriphClockCmd(HCSR04_CLK, ENABLE);
    
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Pin = HCSR04_TRIG;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(HCSR04_PORT, &GPIO_InitStructure);
    GPIO_ResetBits(HCSR04_PORT,HCSR04_TRIG);
    
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Pin = HCSR04_ECHO;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(HCSR04_PORT, &GPIO_InitStructure);   
    GPIO_ResetBits(HCSR04_PORT,HCSR04_ECHO);
  
}


void TIM_Config_Hc(void){
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
    
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
    
	TIM_TimeBaseInitStructure.TIM_Prescaler = 71;
	TIM_TimeBaseInitStructure.TIM_Period = 999;	        //72*50000/72 = 50000us = 500ms.
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInit(HCSR04_TIM,&TIM_TimeBaseInitStructure);
    
	TIM_ClearFlag(HCSR04_TIM,TIM_FLAG_Update);	                //���²����ж�
	TIM_ITConfig(HCSR04_TIM,TIM_IT_Update, ENABLE);                //�򿪶�ʱ�������ж�
	TIM_Cmd(HCSR04_TIM,DISABLE);  
	
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;             
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;  //��ռʽ�ж����ȼ�����Ϊ1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;         //��Ӧʽ�ж����ȼ�����Ϊ1
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;        //ʹ���ж�
	NVIC_Init(&NVIC_InitStructure);
    
    

}


//��ȡ��ʱ��ʱ��
u32 GetEchoTimer()
{
        u32 t = 0;
        
        t = msHcCount * 1000;             //�õ�MS
        t += TIM_GetCounter(HCSR04_TIM);      //�õ�US
				TIM_SetCounter(HCSR04_TIM, 0);        //��TIM2�����Ĵ����ļ���ֵ����
				delay_ms(50);
        
        return t;
}


float Hcsr04GetLength(void)
{
		u32 t = 0;
		int i = 0;
		float lengthTemp = 0;
		float sum = 0;
        
/************** ȡ5�β��������Ϊƽ��ֵ ****************/
//		while(i!=5)
//		{
//            TRIG_Send = 1;      //���Ϳڸߵ�ƽ���
//            delay_us(20);
//            TRIG_Send = 0;
//        
//            while(ECHO_Reci == 0);      //�ȴ����տڸߵ�ƽ���
//            
//			TIM_SetCounter(TIM2, 0);        //�򿪶�ʱ��  
//            msHcCount = 0;
//            TIM_Cmd(TIM2, ENABLE);  //ʹ��TIMx����
//            
//			i = i + 1;
//			while(ECHO_Reci == 1);
//			TIM_Cmd(TIM6, DISABLE);
//            
//			t = GetEchoTimer();        //��ȡʱ��,�ֱ���Ϊ1US
//			lengthTemp = ((float)t/58.0);//cm
//			sum = lengthTemp + sum ;
//	}
//		lengthTemp = sum/5.0;


        TRIG_Send = 1;      //���Ϳڸߵ�ƽ���
        delay_us(20);
        TRIG_Send = 0;
        
        while(ECHO_Reci == 0);      //�ȴ����տڸߵ�ƽ��
        
        TIM_SetCounter(HCSR04_TIM, 0);        //�򿪶�ʱ��  
        
        msHcCount = 0;
        TIM_Cmd(HCSR04_TIM, ENABLE);  //ʹ��TIMx����
            
        while(ECHO_Reci == 1);
		TIM_Cmd(HCSR04_TIM, DISABLE);
            
		t = GetEchoTimer();        //��ȡʱ��,�ֱ���Ϊ1US
		lengthTemp = ((float)t/58.0);//cm
		return lengthTemp;
}

void TIM2_IRQHandler(void)   //TIM2�ж�
{
    if (TIM_GetITStatus(HCSR04_TIM, TIM_IT_Update) != RESET)  //���TIM2�����жϷ������
    {
        TIM_ClearITPendingBit(HCSR04_TIM, TIM_IT_Update);  //���TIMx�����жϱ�־ 
        msHcCount++;
    }
}



