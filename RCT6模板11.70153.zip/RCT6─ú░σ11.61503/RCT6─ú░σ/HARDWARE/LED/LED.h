#ifndef __LED_H
#define __LED_H

#define LED1  PAout(8)
#define LED2  PDout(2)

#define LED_blue 		PCout(0)
#define LED_red			PCout(1)
#define LED_yellow	    PCout(2)
#define LED_green		PCout(3)

void LED_Init(void);


#endif

