#include "E18D80NK.h"
#include "stm32f10x.h"


void E18D80NK_Init(){

    GPIO_InitTypeDef GPIO_InitStructure;
 
 	RCC_APB2PeriphClockCmd(E18D80NK_CLK,ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
    
	GPIO_InitStructure.GPIO_Pin  = E18D80NK_Pin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;	
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(E18D80NK_GPIO, &GPIO_InitStructure);

}


