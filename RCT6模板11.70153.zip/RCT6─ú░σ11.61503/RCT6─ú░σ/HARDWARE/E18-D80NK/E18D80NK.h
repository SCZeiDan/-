#ifndef __E18D80NK_H_
#define __E18D80NK_H_


#define E18D80NK_Pin        GPIO_Pin_3
#define E18D80NK_GPIO       GPIOB
#define E18D80NK_CLK        RCC_APB2Periph_GPIOB


void E18D80NK_Init(void);


#endif 


