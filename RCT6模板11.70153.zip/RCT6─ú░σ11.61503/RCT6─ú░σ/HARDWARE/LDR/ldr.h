#ifndef __LDR_H
#define	__LDR_H


#include "stm32f10x.h"

//// 10:15
//#define ADC_1_Offset    1970
//#define ADC_2_Offset    2020
//#define ADC_3_Offset    1800
//#define Red_1           1400
//#define Red_2           1400
//#define Red_3           1400

// 11:00
//#define ADC_1_Offset    1970
//#define ADC_2_Offset    2020
//#define ADC_3_Offset    1900
//#define Red_1           1500
//#define Red_2           1500
//#define Red_3           1500

////ȡƽ��
//#define ADC_1_Offset    1470
//#define ADC_2_Offset    1520
//#define ADC_3_Offset    1400
//#define Red_1           1500
//#define Red_2           1500
//#define Red_3           1500

#define ADC_1_Offset    1000
#define ADC_2_Offset    1000
#define ADC_3_Offset    1000
#define Left_Diff       110
#define Right_Diff      60		//���� 150����
#define Red_3           1000

void Init_adc(void);
void LoadADC();
void LoadTrueValue();
void Get_ADC_Average(u8 times);
void Load_InitGray();


#endif /* __ADC_H */