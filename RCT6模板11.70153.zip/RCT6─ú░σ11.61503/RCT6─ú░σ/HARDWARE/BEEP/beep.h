#ifndef __BEEP_H
#define __BEEP_H	 
#include "sys.h"

#define BEEP PBout(5)

void BEEP_Init(void);

#endif

/****************Usage

BEEP = 1; 
BEEP = 0; 

****************/

