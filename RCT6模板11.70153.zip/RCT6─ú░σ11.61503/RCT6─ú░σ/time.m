clc;
close all; 
clear;

t = 0 : 0.1: 240;
Vu = 390;
R =  ;
C = 0.00082;

Vt = Vu * (exp(-t/(R*C)));
figure
plot(t, Vt);